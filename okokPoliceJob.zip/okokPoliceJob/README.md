Hi, thank you for buying okokPoliceJob! 🙂

-> Installation Guide: https://docs.okokscripts.io/scripts/okokpolicejob

For support use the links below: 
Discord server: https://discord.gg/okok 
Docs: https://docs.okokscripts.io/